import mdp, util

from learningAgents import ValueEstimationAgent

class ValueIterationAgent(ValueEstimationAgent):
    """
        * Please read learningAgents.py before reading this.*

        A ValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs value iteration
        for a given number of iterations using the supplied
        discount factor.
    """
    def __init__(self, mdp, discount = 0.9, iterations = -1, convergence_delta=0.0):
        """
          The value iteration agent takes an MDP on
          construction, runs the indicated number of iterations
          and then acts according to the resulting policy.

          You will modify the agent to have the following behavior:
            - If convergence_delta < 0, runs for the input number of iterations
            - Otherwise, runs until total change in values is <= convergence_delta
            - If convergence_delta < 0 and iterations == -1, call util.raiseNotDefined()
        """
        self.mdp = mdp
        self.discount = discount
        self.iterations = iterations
        self.values = util.Counter() # A Counter is a dict with default 0

        if convergence_delta >= 0:
            util.raiseNotDefined()

        # initialize all states to value 0
        for state in mdp.getStates():
            self.values[state] = 0

        itr = 0
        for itr in range(iterations):
            # store new values for states in a separate dictionary;
            # we're doing offline computation of the updates
            new_values = util.Counter()

            for state in mdp.getStates():
                action_set = mdp.getPossibleActions(state)
                # special case for terminal states (since not actually terminal)
                if action_set == ('exit',) or len(action_set) == 0:
                    best_score = 0
                # for all other states, check the valid actions
                else:
                    best_score = float('-inf')
                    # find the maximum expected value out of the available actions
                    for action in action_set:
                        transition_info = mdp.getTransitionStatesAndProbs(state, action)
                        # calculate the expected value over all the possible result
                        # states from taking this action
                        score = 0
                        for (next_state, prob) in transition_info:
                            score += prob * self.values[next_state]
                        # if this expected value is the best one we've seen, save it
                        if score > best_score:
                            best_score = score

                # the new value is R(s) + \gamma * the best expected value
                new_values[state] = self.mdp.getReward(state) + self.discount * best_score

            # before overwriting the old values, compute the delta
            delta = 0
            for state in mdp.getStates():
                delta += new_values[state] - self.values[state]

            # now that new values have been computed for all states,
            # overwrite the old values all at once
            self.values = new_values

        if convergence_delta >= 0: print('CONVERGED IN %d' % itr)
        self.convergence_iters = itr


    def getValue(self, state):
        """
          Return the value of the state (computed in __init__).
        """
        return self.values[state]

    def computeActionFromValues(self, state):
        """
          The policy is the best action in the given state
          according to the values currently stored in self.values.

          You may break ties any way you see fit.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return None.
        """
        best_action, best_score = None, float('-inf')

        # out of the possible actions for this state (which may
        # be an empty list!), find the one with highest
        # expected value
        for action in self.mdp.getPossibleActions(state):
            # calculate the expected value of taking this action
            expected_value = 0
            transition_info = self.mdp.getTransitionStatesAndProbs(state, action)
            for (next_state, prob) in transition_info:
                expected_value += prob * self.getValue(next_state)
            # if this is the best outcome we've seen,
            # remember it
            if expected_value > best_score:
                best_action = action
                best_score = expected_value

        return best_action

    def getPolicy(self, state):
        return self.computeActionFromValues(state)

    def getAction(self, state):
        "Returns the policy at the state (no exploration)."
        return self.computeActionFromValues(state)


    #################################################
    ##  STUBS - IGNORE THESE                       ##
    #################################################

    def getQValue(self, state, action):
        return self.computeQValueFromValues(state, action)

    def computeQValueFromValues(self, state, action):
        """
          Compute the Q-value of action in state from the
          value function stored in self.values.
        """
        "STUB"
        return 0

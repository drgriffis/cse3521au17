'''
k-means clustering tests
'''

import numpy as np
#import plotting
test_data = np.load('test_cases/clustering_test_data.npz')

def verify_test(predicted, correct, test_name):
    print('--- Test: %s ---' % test_name)
    if np.all(predicted == correct):
        print('   >>> PASSED! <<<')
        return 1
    else:
        print('   >>> Failed <<<')
        print('   Correct clustering: %s' % str(correct))
        print('   Your clustering:    %s' % str(predicted))
        return 0

def lecture_tests(kmeans):
    data = test_data['lecture_example']
    print('')

    ncorrect, ntests = 0, 0

    # example 1
    centroids = [
        [6.1,6.8],
        [8.8,6.2],
        [8.1,3.1]
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 1, 2, 2, 2])
    ncorrect += verify_test(clustering, correct_clustering, 'Lecture Example 1')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_lecture_clustering_k3', ttl='Lecture clustering (k=3)')

    # example 2
    centroids = [
        [1.7,3.1],
        [4.6,4.8],
        [14,4.5]
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([0, 1, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2])
    ncorrect += verify_test(clustering, correct_clustering, 'Lecture Example 2')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_lecture_clustering_example_2', ttl='Lecture clustering Ex 2 (k=3)')

    # example 3
    centroids = [
        [3.9,5.2],
        [11.4,4.8],
        [15,11]
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1])
    ncorrect += verify_test(clustering, correct_clustering, 'Lecture Example 3 (Bad)')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_lecture_clustering_example_3', ttl='Lecture clustering Ex 3 (k=3)')

    # example 4
    centroids = [
        [4,4],
        [10,3],
        [14,2]
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 1, 2, 2, 2])
    ncorrect += verify_test(clustering, correct_clustering, 'Lecture Example 4')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_lecture_clustering_example_4', ttl='Lecture clustering Ex 4 (k=3)')

    # example 5
    centroids = [
        [1,3],
        [9,9],
        [1,10]
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([0, 2, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
    ncorrect += verify_test(clustering, correct_clustering, 'Lecture Example 5 (Bad)')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_lecture_clustering_example_5', ttl='Lecture clustering Ex 5 (k=3)')

    return ncorrect, ntests

def two_d_gaussian_tests(kmeans):
    data = test_data['two_d_gaussian']
    print('')
    
    ncorrect, ntests = 0, 0

    # test 1
    centroids = [
        [1.419008701815117, 4.9422348239298151],
        [0.013617811931196433, 4.2560291539764652]
    ]
    clustering = kmeans(data, 2, centroids=centroids)
    correct_clustering = np.array([1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1])
    ncorrect += verify_test(clustering, correct_clustering, '2-D Gaussian Test 1 (k=2)')
    ntests += 1

    #plotting.showClustering(data, clustering, 2, fname='TEST_two_d_gaussian_1', ttl='2-d Gaussian Test 1 (k=2)')

    # test 2
    centroids = [
        [5.1984373233435264, 4.7154458150844762],
        [2.0366438626918275, 5.6991519393897292],
    ]
    clustering = kmeans(data, 2, centroids=centroids)
    correct_clustering = np.array([1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1])
    ncorrect += verify_test(clustering, correct_clustering, '2-D Gaussian Test 2 (k=2)')
    ntests += 1

    #plotting.showClustering(data, clustering, 2, fname='TEST_two_d_gaussian_2', ttl='2-d Gaussian Test 2 (k=2)')

    # test 3
    centroids = [
        [3.7249105026575169, 8.2199557385425734],
        [3.9362979004293313, 9.9910266456609769],
        [4.9871967880615085, 2.5358257068412584]
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([2, 1, 2, 2, 2, 1, 2, 2, 0, 1, 0, 2, 2, 2, 2, 0, 2, 2, 2, 2, 0, 2, 1, 2, 0, 2, 0, 2, 0, 2])
    ncorrect += verify_test(clustering, correct_clustering, '2-D Gaussian Test 3 (k=3)')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_two_d_gaussian_3', ttl='2-d Gaussian Test 3 (k=3)')

    # test 4
    centroids = [
        [3.3372017483265215, 2.6361784409517606],
        [1.4319818830997522, 9.7754185977468939],
        [-0.044356042564173026, 6.6634104681873501],
        [-0.067916448406124014, 3.3837381069275918],
        [3.9674427092434308, 5.2686677714089951]
    ]
    clustering = kmeans(data, 5, centroids=centroids)
    correct_clustering = np.array([3, 1, 0, 0, 3, 1, 3, 3, 0, 1, 4, 3, 3, 0, 3, 4, 3, 3, 3, 3, 4, 3, 1, 3, 4, 0, 4, 0, 0, 3])
    ncorrect += verify_test(clustering, correct_clustering, '2-D Gaussian Test 4 (k=5)')
    ntests += 1

    #plotting.showClustering(data, clustering, 5, fname='TEST_two_d_gaussian_4', ttl='2-d Gaussian Test 4 (k=5)')

    return ncorrect, ntests

def two_d_uniform_tests(kmeans):
    data = test_data['two_d_uniform']
    print('')

    ncorrect, ntests = 0, 0

    # test 1
    centroids = [
        [0.064189843563225546, 0.51328469198867599],
        [0.12887181517749313, 0.70877728825274688],
        [0.10872577291298247, 0.85185491987607065],
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([0, 2, 0, 2, 0, 1, 1, 0, 2, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 1, 2, 0, 2, 2, 2, 0, 0, 2, 0, 2])
    ncorrect += verify_test(clustering, correct_clustering, '2-D Uniform Test 1 (k=3)')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_two_d_uniform_1', ttl='2-d Uniform Test 1 (k=3)')

    # test 2
    centroids = [
        [0.38055745105945737, 0.58926801448872834],
        [0.36457512459603891, 0.64704210545757168],
        [0.84037111683780341, 0.48687787181424591],
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([2, 0, 0, 1, 2, 2, 2, 0, 0, 2, 2, 1, 2, 0, 2, 2, 0, 2, 1, 2, 1, 2, 0, 1, 1, 0, 2, 1, 0, 0])
    ncorrect += verify_test(clustering, correct_clustering, '2-D Uniform Test 2 (k=3)')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_two_d_uniform_2', ttl='2-d Uniform Test 2 (k=3)')

    # test 3
    centroids = [
        [0.52635818745606333, 0.24852589536632919],
        [0.31311975260671315, 0.45548267955227506],
        [0.85407755145777331, 0.4184353981161768],
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([0, 1, 0, 1, 2, 2, 2, 0, 1, 2, 2, 2, 0, 0, 2, 2, 0, 0, 1, 2, 1, 0, 1, 1, 1, 0, 2, 1, 0, 1])
    ncorrect += verify_test(clustering, correct_clustering, '2-D Uniform Test 3 (k=3)')
    ntests += 1

    #plotting.showClustering(data, clustering, 3, fname='TEST_two_d_uniform_3', ttl='2-d Uniform Test 3 (k=3)')

    return ncorrect, ntests

def four_d_gaussian_tests(kmeans):
    data = test_data['four_d_gaussian']
    print('')

    ncorrect, ntests = 0, 0

    # test 1
    centroids = [
        [1.2320094750111448, -3.3871173426643306, 1.5835881992146756, -2.381187738096707],
        [2.9698833466474799, -4.5072961999088514, -0.20708995974738942, -2.2036648419960869],
        [2.8521988078744638, 0.69328825315290565, -3.4953829118954713, -2.474694937316829],
    ]
    clustering = kmeans(data, 3, centroids=centroids)
    correct_clustering = np.array([0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 2, 2, 2, 2, 0, 0, 1, 0, 1, 0, 2, 0, 0, 0, 1, 1, 0, 0, 1, 0, 2, 1, 1, 2, 2, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 1, 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 2, 0, 2, 0, 0, 2, 2, 2, 2, 0, 0, 0, 2, 0, 1, 2, 2, 2, 0, 2, 1, 0, 0, 2, 2, 0, 2, 0, 0, 2, 1, 2, 2, 2, 0, 2, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 2, 0, 2, 0, 0, 2, 0, 0, 1, 0, 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 2, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 2, 2, 0, 0, 0, 2, 2, 1, 0, 2, 1, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 1, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 2, 1, 0, 0, 0, 1, 0, 0, 2, 0, 0, 2, 2, 0, 2, 0, 2, 1, 1, 0, 2, 0, 1, 1, 0, 2, 0, 0, 1, 0, 0, 0, 0, 0, 0, 2, 0, 2, 1, 1, 0, 2, 0, 0, 0, 1, 1, 2, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 2, 0, 0, 0, 0, 2, 0, 0, 2, 0, 2, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1, 1, 0, 2, 0, 0, 0, 2, 0, 0, 2, 2, 0, 0, 1, 0, 0, 0, 2, 0, 0, 2, 0, 2, 0, 1, 2, 2, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 2, 0, 0, 0, 0, 2, 0, 2, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2, 0, 2, 1, 0, 2, 1, 2, 0, 2, 0, 0, 0, 1, 2, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 2, 0, 1, 2, 2, 2, 0, 1, 1, 0, 0, 1, 2, 0, 2, 2, 2, 2, 2, 0, 0, 1, 2, 0, 2, 0, 2, 0, 0, 0, 0, 2, 0, 2, 2, 0])
    ncorrect += verify_test(clustering, correct_clustering, '4-D Gaussian Test 1 (k=3)')
    ntests += 1

    # test 2
    centroids = [
        [1.1255518060825862, 1.0444167547918095, -1.3130348571264721, 2.0215392129408558],
        [0.43943021688070516, 2.4438208749361161, -0.86789147711271886, 3.3210150142021284],
        [2.4910713076397668, -2.571103295802335, -1.853791436951985, 1.3053467148185787],
        [-5.0283359109680337, -1.941959059169569, -3.7720737871533792, -3.5848136060994236],
        [-5.0897571156137333, -2.4673713595199764, 2.614019450709594, -1.4766901455018813],
    ]
    clustering = kmeans(data, 5, centroids=centroids)
    correct_clustering = np.array([0, 0, 0, 0, 1, 0, 0, 0, 3, 0, 1, 1, 1, 1, 0, 0, 3, 0, 2, 0, 1, 0, 0, 0, 3, 3, 0, 0, 4, 0, 1, 4, 4, 1, 1, 2, 0, 0, 0, 3, 0, 0, 0, 1, 0, 0, 3, 1, 0, 0, 0, 0, 4, 3, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 3, 1, 1, 1, 0, 1, 3, 0, 0, 1, 1, 0, 1, 0, 0, 1, 3, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 4, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 3, 0, 0, 0, 0, 0, 4, 0, 0, 0, 4, 1, 1, 0, 0, 0, 1, 1, 3, 0, 1, 3, 0, 0, 0, 0, 4, 1, 1, 0, 0, 0, 0, 4, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 0, 1, 2, 0, 0, 0, 2, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 3, 4, 0, 1, 0, 3, 3, 0, 1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 1, 0, 1, 4, 4, 0, 1, 0, 0, 0, 2, 4, 1, 0, 0, 3, 0, 0, 0, 2, 0, 3, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 4, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 2, 3, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 2, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 3, 1, 1, 1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1, 0, 3, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1, 0, 1, 4, 0, 1, 2, 1, 0, 1, 0, 0, 0, 4, 1, 3, 0, 3, 0, 0, 0, 4, 0, 0, 0, 4, 0, 0, 0, 0, 0, 1, 0, 3, 1, 1, 1, 0, 4, 4, 0, 0, 4, 1, 0, 1, 1, 1, 1, 1, 0, 0, 3, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0])
    ncorrect += verify_test(clustering, correct_clustering, '4-D Gaussian Test 2 (k=5)')
    ntests += 1

    return ncorrect, ntests

def runAllTests(kmeans):
    lt_correct, lt_tests = lecture_tests(kmeans)
    tdg_correct, tdg_tests = two_d_gaussian_tests(kmeans)
    tdu_correct, tdu_tests = two_d_uniform_tests(kmeans)
    fdg_correct, fdg_tests = four_d_gaussian_tests(kmeans)

    print('')
    print('Lecture Example test summary: %d/%d tests passed' % (lt_correct, lt_tests))
    print('2-D Gaussian test summary: %d/%d tests passed' % (tdg_correct, tdg_tests))
    print('2-D Uniform test summary: %d/%d tests passed' % (tdu_correct, tdu_tests))
    print('4-D Gaussian test summary: %d/%d tests passed' % (fdg_correct, fdg_tests))

import numpy as np
import plotting
datasets = np.load('test_cases/classification_test_data.npz')

def verify_test(predicted, correct, test_name):
    print('--- Test: %s ---' % test_name)
    if np.all(predicted == correct):
        print('   >>> PASSED! <<<')
        return 1
    else:
        print('   >>> Failed <<<')
        print('   Correct classifications: %s' % str(correct))
        print('   Your classifications:    %s' % str(predicted))
        return 0
    
def lecture_tests(knn):
    ncorrect, ntests = 0, 0

    label_set = datasets['lecture_example_label_set']
    training_data = datasets['lecture_example_training_data']
    training_labels = datasets['lecture_example_training_labels']
    test_data = datasets['lecture_example_test_data']

    expected_labels = [
        'Landscape',
        'Portrait'
    ]
    predicted = knn(training_data, training_labels, test_data, label_set, k=3)
    ncorrect += verify_test(predicted, expected_labels, 'Lecture Example test 1 (Pictures)')
    ntests += 1

    return ncorrect, ntests

def two_class_separated(knn):
    ncorrect, ntests = 0, 0

    label_set = datasets['two_class_separated_label_set']
    training_data = datasets['two_class_separated_training_data']
    training_labels = datasets['two_class_separated_training_labels']
    test_data = datasets['two_class_separated_test_data']

    expected_labels = [
        'Triangle',
        'Circle',
        'Triangle',
        'Triangle'
    ]
    predicted = knn(training_data, training_labels, test_data, label_set, k=1)
    ncorrect += verify_test(predicted, expected_labels, '2-Class Separated test 1 (k=1)')
    ntests += 1

    #plotting.showClassification(training_data, training_labels, test_data, predicted, fname='TEST_class_2-class-separated_k1', ttl='2-Class Separated (k=1)')

    expected_labels = [
        'Triangle',
        'Circle',
        'Triangle',
        'Circle'
    ]
    predicted = knn(training_data, training_labels, test_data, label_set, k=3)
    ncorrect += verify_test(predicted, expected_labels, '2-Class Separated test 2 (k=3)')
    ntests += 1

    #plotting.showClassification(training_data, training_labels, test_data, predicted, fname='TEST_class_2-class-separated_k3', ttl='2-Class Separated (k=3)')

    expected_labels = [
        'Triangle',
        'Circle',
        'Triangle',
        'Circle'
    ]
    predicted = knn(training_data, training_labels, test_data, label_set, k=5)
    ncorrect += verify_test(predicted, expected_labels, '2-Class Separated test 3 (k=5)')
    ntests += 1

    #plotting.showClassification(training_data, training_labels, test_data, predicted, fname='TEST_class_2-class-separated_k5', ttl='2-Class Separated (k=5)')

    expected_labels = [
        'Circle',
        'Circle',
        'Circle',
        'Circle'
    ]
    predicted = knn(training_data, training_labels, test_data, label_set, k=9)
    ncorrect += verify_test(predicted, expected_labels, '2-Class Separated test 4 (k=9)')
    ntests += 1

    #plotting.showClassification(training_data, training_labels, test_data, predicted, fname='TEST_class_2-class-separated_k9', ttl='2-Class Separated (k=9)')

    return ncorrect, ntests


def four_class_gaussian(knn):
    ncorrect, ntests = 0, 0

    label_set = datasets['four_class_gaussian_label_set']
    training_data = datasets['four_class_gaussian_training_data']
    training_labels = datasets['four_class_gaussian_training_labels']
    test_data = datasets['four_class_gaussian_test_data']

    expected_labels = [3, 1, 4, 4, 1, 3, 3, 2, 4, 4, 4, 3, 2, 1, 2, 2, 4, 2, 1, 1, 3, 4, 3, 4, 3, 3, 1, 2, 4, 2, 2, 4, 2, 4, 2, 1, 2, 4, 1, 1, 3, 3, 3, 1, 3, 2, 2, 4, 1, 1]
    predicted = knn(training_data, training_labels, test_data, label_set, k=1)
    ncorrect += verify_test(predicted, expected_labels, '4-Class Gaussian test 1 (k=1)')
    ntests += 1

    #plotting.showClassification(training_data, training_labels, test_data, predicted, fname='TEST_class_4-class-gaussian_k1', ttl='4-Class Gaussian (k=1)')

    expected_labels = [3, 4, 1, 1, 1, 3, 3, 2, 4, 4, 1, 3, 2, 1, 2, 2, 4, 2, 1, 1, 3, 4, 2, 4, 2, 3, 1, 2, 1, 2, 2, 2, 2, 4, 2, 1, 2, 3, 1, 1, 3, 3, 2, 4, 3, 1, 2, 3, 1, 1]
    predicted = knn(training_data, training_labels, test_data, label_set, k=3)
    ncorrect += verify_test(predicted, expected_labels, '4-Class Gaussian test 2 (k=3)')
    ntests += 1

    #plotting.showClassification(training_data, training_labels, test_data, predicted, fname='TEST_class_4-class-gaussian_k3', ttl='4-Class Gaussian (k=3)')

    expected_labels = [3, 4, 2, 3, 1, 3, 3, 2, 4, 4, 2, 3, 2, 1, 2, 2, 4, 2, 1, 1, 3, 4, 2, 4, 4, 3, 3, 2, 2, 2, 2, 4, 2, 4, 2, 1, 2, 3, 1, 1, 1, 1, 2, 4, 1, 2, 2, 3, 1, 1]
    predicted = knn(training_data, training_labels, test_data, label_set, k=15)
    ncorrect += verify_test(predicted, expected_labels, '4-Class Gaussian test 3 (k=15)')
    ntests += 1

    #plotting.showClassification(training_data, training_labels, test_data, predicted, fname='TEST_class_4-class-gaussian_k15', ttl='4-Class Gaussian (k=15)')

    return ncorrect, ntests


def runAllTests(knn):
    lt_correct, lt_tests = lecture_tests(knn)
    print('')
    tcs_correct, tcs_tests = two_class_separated(knn)
    print('')
    fcg_correct, fcg_tests = four_class_gaussian(knn)

    print('')
    print('Lecture Example test summary: %d/%d tests passed' % (lt_correct, lt_tests))
    print('2-class Separated test summary: %d/%d tests passed' % (tcs_correct, tcs_tests))
    print('4-class Gaussian test summary: %d/%d tests passed' % (fcg_correct, fcg_tests))

'''
Implementation of logistic regression with gradient descent training
'''

import numpy as np
import datasets
import plotting

def logistic(w,x):
    return 1./(1+np.exp(-np.dot(w,x)))

class LogisticRegression:
    
    def __init__(self):
        pass

    def train(self, data, labels, seed=None, convergence_delta=0.0005, learning_rate=0.01, plots=False, plots_interval=10, plots_use_data_bounds=True):
        """
        Fit a logistic regression to the specified labeled (training) data.
        Runs until the change in Sum of Squared Error (SSE) over the training set from one
        complete iteration over the data to the next falls below convergence_delta.

        Inputs:
            data                  -- a Numpy array of data points to fit to
            labels                -- a 1-D Numpy array of labels for the points in data;
                                     labels[i] is the label for point data[i]
            seed                  -- the seed for the random number generator; specify a seed
                                     if you want consistent behavior from one run to the next
            convergence_delta     -- the threshold for convergence (stopping training);
                                     when the change in SSE on the training_set from
                                     one iteration to the next falls below this, training
                                     has converged
            learning_rate         -- the value of \alpha to use in updating the weights of the
                                     regression line
            plots                 -- Boolean; if True, will generate .png files showing the training
                                     data and the current regression line in the plots/ directory
                                     (REQUIRES MATPLOTLIB)
            plots_interval        -- (ONLY USED IF plots=True); the number of iterations to wait
                                     between generating .png files with the current regression line
            plots_use_data_bounds -- Boolean; if True, restricts the plot files to use
                                     (x,y) bounds around the training data; this may hide the actual
                                     regression line
        """
        self.learning_rate = learning_rate
        self.nfeatures = data.shape[1]+1
        if seed: np.random.seed(seed)
        self.weights = np.random.uniform(size=(self.nfeatures,))

        row_indices = np.array(range(len(data)))
        # pad the data with 1s for bias correction
        padded_data = np.concatenate([data, np.ones(shape=(data.shape[0],1))], axis=1)

        if plots:
            plotting.showRegressionLine(data, labels, self.weights, fname='plots/regression_initial_state', ttl='Logistic Regression Initialization', use_data_bounds=plots_use_data_bounds)

        delta = 10000
        prev_error = float('inf')
        iterations = 0
        # run until decrease in training loss falls below the threshold
        while delta > convergence_delta:
            # reshuffle and re-iterate over the data
            np.random.shuffle(row_indices)
            for row in row_indices:
                self.update_weights(padded_data[row], labels[row])
            # calculate training set error
            new_error = self.SSE(padded_data, labels)
            # calculate decrease in training loss
            delta = prev_error - new_error
            prev_error = new_error
            iterations += 1

            if plots and iterations % plots_interval == 0:
                plotting.showRegressionLine(data, labels, self.weights, fname='plots/regression_iteration_%d' % iterations, ttl='Logistic Regression progress (Iteration %d)' % iterations, use_data_bounds=plots_use_data_bounds)

        if plots:
            plotting.showRegressionLine(data, labels, self.weights, fname='plots/regression_complete', ttl='Logistic Regression completed (Iteration %d)' % iterations, use_data_bounds=plots_use_data_bounds)

        return new_error, iterations

    def update_weights(self, point, label):
        prediction = self.soft_predict(point)
        new_weights = np.zeros(shape=(self.nfeatures,))
        for i in range(self.nfeatures):
            new_weights[i] = (
                self.weights[i] + (
                    ( self.learning_rate*(label-prediction) ) *
                    ( prediction*(1-prediction) ) *
                    point[i]
                )
            )
        self.weights = new_weights

    def soft_predict(self, point):
        return logistic(self.weights, point)

    def predict(self, point):
        soft_prediction = logistic(self.weights, np.concatenate([point, [1]]))
        if soft_prediction >= 0.5: return 1
        else: return 0

    def accuracy(self, data, labels):
        correct = 0.
        for row in range(data.shape[0]):
            hard_prediction = self.predict(data[row])
            if hard_prediction == labels[row]: correct += 1
        return correct/data.shape[0]

    def SSE(self, data, labels):
        error = 0.
        for row in range(data.shape[0]):
            error += ((labels[row]-self.soft_predict(data[row]))**2)
        return error

if __name__=='__main__':
    lr = LogisticRegression()

    ## Perfectly separable dataset
    separable_training_data = datasets.logreg['two_gaussian_separable_training_data']
    separable_training_labels = datasets.logreg['two_gaussian_separable_training_labels']
    separable_test_data = datasets.logreg['two_gaussian_separable_test_data']
    separable_test_labels = datasets.logreg['two_gaussian_separable_test_labels']

    ## Mostly separable dataset
    medium_training_data = datasets.logreg['two_gaussian_medium_training_data']
    medium_training_labels = datasets.logreg['two_gaussian_medium_training_labels']
    medium_test_data = datasets.logreg['two_gaussian_medium_test_data']
    medium_test_labels = datasets.logreg['two_gaussian_medium_test_labels']

    ## Totally inseparable dataset
    inseparable_training_data = datasets.logreg['two_gaussian_inseparable_training_data']
    inseparable_training_labels = datasets.logreg['two_gaussian_inseparable_training_labels']
    inseparable_test_data = datasets.logreg['two_gaussian_inseparable_test_data']
    inseparable_test_labels = datasets.logreg['two_gaussian_inseparable_test_labels']

    ## Feature exploration dataset
    features_training_data = datasets.logreg['two_gaussian_features_training_data']
    features_training_labels = datasets.logreg['two_gaussian_features_training_labels']
    features_test_data = datasets.logreg['two_gaussian_features_test_data']
    features_test_labels = datasets.logreg['two_gaussian_features_test_labels']


    ## Train a Logistic Regression
    (err, itr) = lr.train(
        separable_training_data,
        separable_training_labels,
        #seed=1066,
        plots=True,
        convergence_delta=0.1,
        #learning_rate=0.001
        learning_rate=0.1,
        plots_use_data_bounds=False
    )
    print('Training error (SSE): %.10f' % err)
    print('Iterations: %d' % itr)
    print('Training set accuracy: %.2f%%' % (100*lr.accuracy(
        separable_training_data,
        separable_training_labels,
    )))
    print('Test set accuracy: %.2f%%' % (100*lr.accuracy(
        separable_test_data,
        separable_test_labels,
    )))

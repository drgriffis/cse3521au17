'''
k-Means algorithm for clustering

CSE 3521 Homework 5, Question 3
'''

import numpy as np

def kMeans(data, k, centroids=None):
    '''Your implementation of k-Means clustering.

    DO NOT CHANGE THE METHOD SIGNATURE!

    Inputs:
        data      -- a Numpy array of points to cluster
                     (one point per row in the matrix)
        k         -- the number of clusters to use
        centroids -- OPTIONAL; pre-initialized centroids to use for clustering
                     (used by the test cases).  If not input, random centroids
                     will be generated.

    Outputs:
        clustering -- a list of cluster indices, where clustering[i] is the cluster
                      that data[i] is assigned to
                      
                      E.g., k=3, clustering=[0, 2, 1, 2, 0, 0, 2] means that data[0]
                      is in cluster 0, data[1] is in cluster 2, etc.
    '''

    if not centroids:
        centroids = initializeCentroids(data, k)

    # Default clustering: CHANGE THIS
    clustering = [0 for _ in range(data.shape[0])]

    """ YOUR CODE HERE """

    return clustering


######################################################
### DO NOT CHANGE THIS METHOD ########################
######################################################
def initializeCentroids(data, k, use_points=False):
    # cluster centroid initialization
    if use_points:
        indices = list(range(data.shape[0]))
        np.random.shuffle(indices)
        centroids = data[indices[:k]]
    # use random uniform over feature bounds
    else:
        feature_mins = np.min(data, axis=0)
        feature_maxs = np.max(data, axis=0)
        feature_rngs = feature_maxs-feature_mins
        centroids = []
        for _ in range(k):
            centroid = [
                feature_mins[i] + (
                    np.random.random() * feature_rngs[i]
                ) for i in range(data.shape[1])
            ]
            centroids.append(centroid)
        centroids = np.array(centroids)

    return centroids

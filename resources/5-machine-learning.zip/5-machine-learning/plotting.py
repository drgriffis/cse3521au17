'''
'''
import numpy as np
try:
    import matplotlib.pyplot as plt
    import matplotlib.cm as cm
    NOMATPLOTLIB=False
except ImportError:
    print('[WARNING] Attempting to use plotting module without matplotlib installed.  All calls to plotting methods will fail silently.')
    NOMATPLOTLIB=True

_master_classification_label_markers = {
    'Triangle':'^',
    'Circle':'o',
    1:'8',
    2:'*',
    3:'D',
    4:'^',
    0:'^'
}
_master_classification_label_colors = {
    'Triangle':'orange',
    'Circle':'blue',
    1:'blue',
    2:'red',
    3:'orange',
    4:'green',
    0:'red'
}

def scatter(data, fname='scatterplot', ttl='Scatterplot'):
    if NOMATPLOTLIB: return
    fig = plt.figure()
    ax = fig.add_subplot(1,1,1,facecolor="1.0")
    ax.scatter(data[:,0], data[:,1], s=80, c='black')
    plt.title(ttl)
    plt.savefig('%s.png' % fname)
    plt.close()

def showClustering(data, clustering, k, fname='clustering', ttl='Current Clustering', centroids=None, show_clusters=True):
    if NOMATPLOTLIB: return
    if data.shape[1] != 2:
        raise Exception('Cannot plot non 2-d data!')

    fig = plt.figure()
    ax = fig.add_subplot(1,1,1,facecolor="1.0")

    cluster_colors = cm.rainbow(np.linspace(0, 1, k))
    
    if show_clusters: point_colors = [cluster_colors[i] for i in clustering]
    else: point_colors = ['black' for _ in clustering]
    ax.scatter(data[:,0], data[:,1], s=80, c=point_colors)

    if centroids:
        centroids = np.array(centroids)
        ax.scatter(centroids[:,0], centroids[:,1], s=200, c=cluster_colors)

    plt.title(ttl)
    plt.savefig(fname)
    plt.close()

def showClassification(training_data, training_labels, test_data, test_labels, fname='classification', ttl='Current Classification', show_test_labels=True):
    if NOMATPLOTLIB: return
    if training_data.shape[1] != 2:
        raise Exception('Cannot plot non 2-d data!')

    test_labels = np.array(test_labels)

    fig = plt.figure()
    ax = fig.add_subplot(1,1,1,facecolor="1.0")

    for lbl in set(training_labels).union(set(test_labels)):
        if lbl is None: continue
        data_subset = training_data[np.where(training_labels == lbl)]
        if data_subset.shape[0] > 0:
            ax.scatter(data_subset[:,0], data_subset[:,1], s=80, c=_master_classification_label_colors[lbl], marker=_master_classification_label_markers[lbl])
        if show_test_labels:
            data_subset = test_data[np.where(test_labels == lbl)]
            if data_subset.shape[0] > 0:
                ax.scatter(data_subset[:,0], data_subset[:,1], s=150, c=_master_classification_label_colors[lbl], marker=_master_classification_label_markers[lbl])
    if not show_test_labels and test_data.shape[0]>0:
        ax.scatter(test_data[:,0], test_data[:,1], s=150, c='black', marker='x')

    plt.title(ttl)
    plt.savefig(fname)
    plt.close()

def showRegressionLine(training_data, training_labels, weights, fname='regression', ttl='Current regression', use_data_bounds=True):
    if NOMATPLOTLIB: return
    if training_data.shape[1] != 2:
        raise Exception('Cannot plot non 2-d data!')

    low_x_bound = np.min(training_data[:,0])
    high_x_bound = np.max(training_data[:,0])
    low_y_bound = np.min(training_data[:,1])
    high_y_bound = np.max(training_data[:,1])

    sampled_x = np.arange(low_x_bound, high_x_bound, 0.2)
    sampled_y = ((-weights[0]*sampled_x)-weights[2])/weights[1]
    if use_data_bounds:
        sampled_x = sampled_x[(sampled_y >= low_y_bound) & (sampled_y <= high_y_bound)]
        sampled_y = sampled_y[(sampled_y >= low_y_bound) & (sampled_y <= high_y_bound)]

    fig = plt.figure()
    ax = fig.add_subplot(1,1,1,facecolor="1.0")

    # scatter the training data
    for lbl in set(training_labels):
        if lbl is None: continue
        data_subset = training_data[np.where(training_labels == lbl)]
        if data_subset.shape[0] > 0:
            ax.scatter(data_subset[:,0], data_subset[:,1], s=80, c=_master_classification_label_colors[lbl], marker=_master_classification_label_markers[lbl])
    # plot the regression line
    ax.plot(sampled_x, sampled_y)

    plt.title(ttl)
    plt.savefig(fname)
    plt.close()

'''
k-Nearest Neighbors algorithm for classification

CSE 3521 Homework 5, Question 2
'''

import numpy as np


def kNearestNeighbors(training_data, training_labels, test_data, label_set, k):
    '''Your implementation of k-Nearest Neighbors classification.

    DO NOT CHANGE THE METHOD SIGNATURE!

    Inputs:
        training_data   -- a 2-d Numpy array of training data points; use training_data[i]
                           to get row i, training_data[i,j] to get column j of row i.
        training_labels -- a 1-d Numpy array of labels for the rows in training_data;
                           training_labels[i] is the label for row training_data[i].
        test_data       -- a 2-d Numpy array of test data points that you will classify;
                           indexable just like training_data.
        label_set       -- a 1-d Numpy array of the unique labels you can classify points as.

    Outputs:
        test_labels -- a list of labels (from label_set) for each point in test_data;
                       test_labels[i] must be the label for point test_data[i].
    '''
    test_labels = [label_set[0] for _ in test_data]
    """YOUR CODE HERE"""
    return test_labels

#####################################################
### DO NOT CHANGE THIS METHOD #######################
#####################################################
def distance(a, b):
    '''Using Euclidean distance'''
    return np.linalg.norm(np.array(a) - np.array(b))

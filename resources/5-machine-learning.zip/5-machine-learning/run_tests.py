'''
'''

from knn import kNearestNeighbors
from kmeans import kMeans

from test_cases import classification_tests
from test_cases import clustering_tests

print('')
print('#################################################')
print(' k-Nearest Neighbors classification tests')
print('#################################################')
print('')
classification_tests.runAllTests(kNearestNeighbors)

print('')
print('#################################################')
print(' k-Means clustering tests')
print('#################################################')
print('')
clustering_tests.runAllTests(kMeans)

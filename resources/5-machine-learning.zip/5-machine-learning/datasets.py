'''
'''

import numpy as np

clustering = np.load('test_cases/clustering_test_data.npz')
classification = np.load('test_cases/classification_test_data.npz')
logreg = np.load('test_cases/logreg_test_data.npz')
